import java.util.concurrent.*;
class Order {}
class ExchangeManager{
    ConcurrentHashMap<String, CopyOnWriteArrayList<Order>> orderBook=new ConcurrentHashMap<>();
    void placeOrder(String ticker, Order order){
        orderBook.computeIfAbsent(ticker,k->new CopyOnWriteArrayList<>()).add(order);
    }
}

import java.util.*;
enum TriageLevel { CRITICAL, URGENT, STABLE }

class Patient implements Comparable<Patient>{
    String name; TriageLevel severity; long arrivalTime;
    public int compareTo(Patient p){
        int s=Integer.compare(severity.ordinal(), p.severity.ordinal());
        return s!=0 ? s : Long.compare(arrivalTime,p.arrivalTime);
    }
}

class TriageManager{
    PriorityQueue<Patient> queue=new PriorityQueue<>();
    void admitPatient(Patient p){ queue.add(p); }
    Patient getNextPatient(){ return queue.poll(); }
}

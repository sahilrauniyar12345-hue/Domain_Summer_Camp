// Coding Problem 1
import java.util.*;

class Passenger {
    String passportNumber, fullName, nationality;
    Passenger(String p, String f, String n){passportNumber=p;fullName=f;nationality=n;}
    public boolean equals(Object o){
        if(this==o) return true;
        if(!(o instanceof Passenger)) return false;
        Passenger p=(Passenger)o;
        return passportNumber.equals(p.passportNumber) && nationality.equals(p.nationality);
    }
    public int hashCode(){ return Objects.hash(passportNumber,nationality); }
}

class ManifestManager {
    Set<Passenger> globalNoFlyList = new HashSet<>();
    Map<String,List<Passenger>> flightRosters = new HashMap<>();
    Map<Passenger,String> globalPassengerDirectory = new HashMap<>();

    public void addToNoFlyList(Passenger p){ globalNoFlyList.add(p); }

    public boolean processCheckIn(String flightNumber, Passenger p){
        if(globalNoFlyList.contains(p)) return false;
        flightRosters.computeIfAbsent(flightNumber,k->new ArrayList<>()).add(p);
        globalPassengerDirectory.put(p, flightNumber);
        return true;
    }

    public String locatePassengerFlight(Passenger p){
        return globalPassengerDirectory.get(p);
    }
}

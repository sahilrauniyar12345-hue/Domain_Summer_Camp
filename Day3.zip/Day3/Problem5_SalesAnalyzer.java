import java.util.*;
class Transaction{
    String status, category; double amount;
}
class SalesAnalyzer{
    public double calculateElectronicsRevenue(List<Transaction> txns){
        return txns.stream()
            .filter(t->"COMPLETED".equals(t.status))
            .filter(t->"ELECTRONICS".equals(t.category))
            .mapToDouble(t->t.amount)
            .sum();
    }
}

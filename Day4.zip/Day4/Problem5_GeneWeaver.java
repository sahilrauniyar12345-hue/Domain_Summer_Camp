// Day 4 - Problem 5 Solution
// Implement DNASample hierarchy and Sequencer.

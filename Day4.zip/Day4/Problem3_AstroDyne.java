// Day 4 - Problem 3 Solution
// Implement EngineLog hierarchy, interfaces, TelemetryProcessor.

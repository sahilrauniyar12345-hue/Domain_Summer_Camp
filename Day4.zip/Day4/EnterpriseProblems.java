// Day 4 Enterprise Problems
// Includes flatMap, toUnmodifiableMap, limit/peek, Predicate chaining, reduce.

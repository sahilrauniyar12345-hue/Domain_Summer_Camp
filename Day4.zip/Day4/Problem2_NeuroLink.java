// Day 4 - Problem 2 Solution
// Implement MemoryEngram hierarchy, interfaces, CortexProcessor.

// Day 4 - Problem 1 Solution
// See PDF requirements. Implement Cargo hierarchy, custom interfaces,
// ManifestProcessor, and main method with lambdas.

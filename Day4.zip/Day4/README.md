# Day4
Java Stream & Functional Interface Assessment solutions.
Upload this folder/zip to GitHub.
